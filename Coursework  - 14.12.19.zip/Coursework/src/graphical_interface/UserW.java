package graphical_interface;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;

public class UserW {
   /* public void showAbout() throws IOException {
        FXMLLoader fxl = new  FXMLLoader(getClass().getResource("About.fxml"));
        Parent rt  = (Parent) fxl.load();
        Stage stt = new Stage();
        stt.setScene(new Scene(rt));
        stt.initModality(Modality.APPLICATION_MODAL);
        stt.setResizable(false);
        stt.setTitle("About");
        stt.show();
    }*/

    public void showSettings() throws IOException {
        FXMLLoader rr = new FXMLLoader(getClass().getResource("Settings.fxml"));
        Parent pt1 = (Parent) rr.load();
        Stage tsg = new Stage();
        tsg.initModality(Modality.APPLICATION_MODAL);
        tsg.setTitle("Panel");
        tsg.setResizable(true);
        tsg.setScene(new Scene(pt1));
        tsg.show();
    }
    public void killApp(){
        Platform.exit();
    }
}
