package graphical_interface;
import business_logic.User;
import database_logic.UserCollector;
import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javafx.collections.ObservableList;
import javafx.util.Callback;

public class VUsers {
@FXML
private TableView TView;
//private ObservableList<ObservableList> data;
ObservableList<User> ob = (ObservableList<User>) UserCollector.collectU;
//- - - - - - - - - - - - - -  - - - - - - - - -
public void vData() throws ClassNotFoundException, SQLException {
TView.setItems(ob);


}
}


