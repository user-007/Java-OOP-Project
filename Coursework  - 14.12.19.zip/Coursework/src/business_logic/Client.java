package business_logic;

public class Client {
}
