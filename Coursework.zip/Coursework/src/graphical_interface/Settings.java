package graphical_interface;

import javafx.scene.control.Button;

public class Settings {

    public Button vusers;
    public void vUsers(){

    }
}
