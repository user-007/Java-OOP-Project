/*
package database_logic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RetrieveUsers {
    public void retrieveAll() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l", "CXcocPWj6l", "czNrEV9umD");
        String query  = "select Username,PassWord from User where Username = ? and PassWord = ?";

    }

}
*/
