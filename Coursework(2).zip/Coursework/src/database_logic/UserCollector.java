package database_logic;
import business_logic.User;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;


public class UserCollector {
    public static List<User> collectU = new ArrayList<User>();
    public static List<Product>  prods = new ArrayList<>();
    public static List<User> current  = new ArrayList<>();

}
