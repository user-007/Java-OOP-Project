package database_logic;
import graphical_interface.Controller;
import graphical_interface.UserW;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegClient {
    public void RegisterClient() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l?autoReconnect=true&useSSL=false", "CXcocPWj6l", "czNrEV9umD");
        System.out.println("Connection established");
        String query  = "insert into Customers(Name,Email,PhoneNumber,CreatedBy) values(?,?,?,?)";
        PreparedStatement reg_cl = conn.prepareStatement(query);
        reg_cl.setString(1, UserW.nam);
        reg_cl.setString(2,UserW.emaill);
        reg_cl.setString(3,UserW.ph_num);
        reg_cl.setInt(4,Controller.ID);
        reg_cl.executeUpdate();
        conn.close();
    }
}
