package database_logic;
import graphical_interface.MOLCreate;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class WriteMOLtoDatabase {

    public void WriteMOL() throws SQLException, ClassNotFoundException {
        try {

            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l?autoReconnect=true&useSSL=false", "CXcocPWj6l", "czNrEV9umD");
            System.out.println("Connection established");
            String query  = "INSERT INTO User(Name,Username,PassWord) VALUES(?,?,?)";
            PreparedStatement insertUser = conn.prepareStatement(query);
            insertUser.setString(1,MOLCreate.fieldUsername);
            insertUser.setString(2,MOLCreate.fieldUsername);
            insertUser.setString(3,MOLCreate.fieldPassword);
            //insertUser = conn.prepareStatement(query);
            insertUser.executeUpdate();
            conn.close();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Success!");
            alert.show();
        } catch(Exception eptn){
            System.out.println(eptn.getMessage());
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error!");
            alert.show();
        }

    }
}
