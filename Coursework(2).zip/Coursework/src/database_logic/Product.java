package database_logic;

public class Product {
}
