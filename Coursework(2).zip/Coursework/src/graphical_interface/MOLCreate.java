package graphical_interface;
import database_logic.*;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MOLCreate {

    @FXML
    private  TextField fd1;
    @FXML
    private  TextField fd2;
    @FXML
    private  TextField fd3;

    public static String fieldName ;
    public static String fieldUsername ;
    public static String fieldPassword ;

    @FXML
    private void actionCreate() throws SQLException, ClassNotFoundException {
        fieldName  =  fd1.getText();
        fieldUsername = fd2.getText();
        fieldPassword = fd3.getText();
        try{
           WriteMOLtoDatabase wmtdb = new WriteMOLtoDatabase();
           wmtdb.WriteMOL();
        }
        catch(Exception pt){
            System.out.println(pt.getMessage());
        }
    }
}
