package graphical_interface;

import business_logic.User;
import database_logic.UserCollector;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class Settings {

    public void viewAll() {
     try{
          /*//  FXMLLoader pj = new FXMLLoader(getClass().getResource("View users.fxml"));
            Parent prt1 = (Parent) pj.load();
            Stage tsg = new Stage();
            tsg.initModality(Modality.APPLICATION_MODAL);
            tsg.setTitle("Panel");
            tsg.setResizable(true);
            tsg.setScene(new Scene(prt1));
            tsg.show();*/
         try{
             TableView tableView = new TableView();

             TableColumn<Integer, User> column1 = new TableColumn<>("ID");
             column1.setCellValueFactory(new PropertyValueFactory<>("id"));


             TableColumn<String, User> column2 = new TableColumn<>("Name");
             column2.setCellValueFactory(new PropertyValueFactory<>("name"));
             TableColumn<String, User> column3 = new TableColumn<>("Username");
             column3.setCellValueFactory(new PropertyValueFactory<>("username"));
             TableColumn<String, User> column4 = new TableColumn<>("Password");
             column4.setCellValueFactory(new PropertyValueFactory<>("password"));
             TableColumn<Boolean, User> column5 = new TableColumn<>("Role");
             column5.setCellValueFactory(new PropertyValueFactory<>("role"));
             tableView.getColumns().add(column1);
             tableView.getColumns().add(column2);
             tableView.getColumns().add(column3);
             tableView.getColumns().add(column4);
             tableView.getColumns().add(column5);
             for(User u: UserCollector.collectU){
                 tableView.getItems().add(new User(u.getId(),u.getName(),u.getUsername(),u.getPassword(),u.isRole()));
             }
             VBox vbox = new VBox(tableView);
             Scene scene = new Scene(vbox);
             Stage stge = new Stage();
             stge.setScene(scene);
             stge.show();
         }catch(Exception ep){
             System.out.println(ep.getCause());
         }
        }
        catch(Exception ept){
            System.out.println(ept.getMessage());
        }
    }
public void openMOL() {
        try{
    FXMLLoader load_MOL = new FXMLLoader(getClass().getResource("MOLCreate.fxml"));
    Parent t1 = (Parent) load_MOL.load();
    Stage sg = new Stage();
    sg.initModality(Modality.APPLICATION_MODAL);
    sg.setTitle("Panel");
    sg.setResizable(false);
    sg.setScene(new Scene(t1));
    sg.show();
        }
        catch(Exception er){
            System.out.println(er.getMessage());
        }

    }
}
