package graphical_interface;

import database_logic.RegClient;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
public class UserW {
    @FXML
    private TextField nField;
    @FXML
    private TextField eField;
    @FXML
    private TextField pField;
    @FXML
    private RadioButton rb1;
    @FXML
    private RadioButton rb2;
    @FXML
    private  ChoiceBox<Integer> chBox;
    final ToggleGroup group = new ToggleGroup();
    ObservableList<Integer> names = FXCollections.observableArrayList(1,2,3,4);
    ObservableList<String> nms = FXCollections.observableArrayList(
            "Computer",
            "Book",
            "TV",
            "Camera",
            "Appliances",
            "Other"
    );
  @FXML
  private MenuItem adItem;
  @FXML
  private ChoiceBox<String> prodType;
  @FXML
  private TextField pricee;
    public static String nam;
    public static String emaill;
    public static String ph_num;
    public void initialize(){
    rb1.setToggleGroup(group);
    rb1.setSelected(true);
    rb2.setToggleGroup(group);
    if(!Controller.fg){
        adItem.setDisable(true);
    }
    chBox.setItems(names);
    chBox.getSelectionModel().select(0);
    prodType.setItems(nms);
    prodType.getSelectionModel().select(5);
}
    public void showSettings() throws IOException {
        FXMLLoader p = new FXMLLoader(getClass().getResource("Settings.fxml"));
        Parent pt1 = (Parent) p.load();
        Stage tsg = new Stage();
        tsg.initModality(Modality.APPLICATION_MODAL);
        tsg.setTitle("Panel");
        tsg.setResizable(true);
        tsg.setScene(new Scene(pt1));
        tsg.show();
    }
    public void showAbout() throws IOException {

        FXMLLoader rr = new FXMLLoader(getClass().getResource("About.fxml"));
        Parent pt1 = (Parent) rr.load();
        Stage tsg = new Stage();
        tsg.initModality(Modality.APPLICATION_MODAL);
        tsg.setTitle("About");
        tsg.setResizable(false);
        tsg.setScene(new Scene(pt1));
        tsg.show();
    }
    public void writeClient() throws IOException, ClassNotFoundException, SQLException {
        try {
            nam = nField.getText();
            emaill = eField.getText();
            ph_num = pField.getText();
            RegClient rcl = new RegClient();
            rcl.RegisterClient();
            Alert suc = new Alert(Alert.AlertType.INFORMATION, "Success!");
            suc.show();
        } catch (Exception ex) {
            Alert al = new Alert(Alert.AlertType.ERROR, "Unable to create client!");
            al.show();
        }
    }
    public void showQuery() throws IOException {
        FXMLLoader pp = new FXMLLoader(getClass().getResource("Queries.fxml"));
        Parent pt1 = (Parent) pp.load();
        Stage tsg = new Stage();
        tsg.initModality(Modality.APPLICATION_MODAL);
        tsg.setTitle("Query");
        tsg.setResizable(false);
        tsg.setScene(new Scene(pt1));
        tsg.show();
    }
    public void registerProd() throws SQLException, ClassNotFoundException {
        try{
        Date st = new Date();
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l?autoReconnect=true&useSSL=false", "CXcocPWj6l", "czNrEV9umD");
        String query = "insert into Product(ProductType_idProductType,Amortization_idAmortization,IsDMA,IsDiscarded,CreadedBy,DateCreated) values(?,?,?,?,?,?,?)";
        PreparedStatement pstmt2 = conn.prepareStatement(query);
            pstmt2.setInt(1,1);
            pstmt2.setInt(2,1);

        if(rb1.isSelected()){
         pstmt2.setBoolean(3,true);
        }
        else{
            pstmt2.setBoolean(3,false);

        }        pstmt2.setBoolean(4,false);
        pstmt2.setInt(5,Controller.ID);
        pstmt2.setDate(6, new java.sql.Date(st.getTime()));
        pstmt2.setString(7,pricee.getText());
        pstmt2.executeUpdate();
        }
        catch(Exception ept){
            System.out.println(ept.getMessage());
        }

    }
    public void killApp(){
        Platform.exit();
    }
}

