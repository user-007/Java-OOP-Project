package graphical_interface;

import business_logic.User;
import database_logic.UserCollector;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class Queries {
    public void vProducts() throws ClassNotFoundException, SQLException {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l?autoReconnect=true&useSSL=false", "CXcocPWj6l", "czNrEV9umD");
                String query = "select * from Product;";
                PreparedStatement pstmt2 = conn.prepareStatement(query);
                ResultSet valueExist = pstmt2.executeQuery(query);
                ResultSetMetaData rsmd = valueExist.getMetaData();
                int colnum = rsmd.getColumnCount();
                while (valueExist.next()) {
                    UserCollector.collectU.add(
                            new User(
                                    valueExist.getInt("idUser"),
                             valueExist.getString("Name"),
                             valueExist.getString("Username"),
                             valueExist.getString("PassWord"),
                             valueExist.getBoolean("Role")
                            )

                    );
                }
    }
}