package graphical_interface;

import business_logic.User;
import database_logic.UserCollector;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.*;

public class Controller {
    @FXML
    public Button loginB;
    public Button exitB;
    public TextField userinp;
    public TextField passinp;
    public Parent pr;
    public Stage st;
    public byte flag = 0;
    public int countTimes = 0;
    public static String name_of_user;
    public static int ID;
    public static Boolean fg;
    @FXML
    private void closeApp() {
        Platform.exit();
    }

    @FXML
    private void checkB() {

        try {
            try {

                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://remotemysql.com/CXcocPWj6l?autoReconnect=true&useSSL=false", "CXcocPWj6l", "czNrEV9umD");
                String query = "SELECT * FROM CXcocPWj6l.User;";
                PreparedStatement pstmt2 = conn.prepareStatement(query);
                ResultSet valueExist = pstmt2.executeQuery(query);
                ResultSetMetaData rsmd = valueExist.getMetaData();
                int colnum = rsmd.getColumnCount();
                while (valueExist.next()) {
                    UserCollector.collectU.add(
                            new User(
                                    valueExist.getInt("idUser"),
                                    valueExist.getString("Name"),
                                    valueExist.getString("Username"),
                                    valueExist.getString("PassWord"),
                                    valueExist.getBoolean("Role")
                            )

                    );
                }
                conn.close();
                for (int i = 0; i < UserCollector.collectU.size(); i++) {
                    if (UserCollector.collectU.get(i).getUsername().equals(userinp.getText()) && UserCollector.collectU.get(i).getPassword().equals(passinp.getText())) {
                        flag = 1;
                        name_of_user = userinp.getText();
                        if (UserCollector.collectU.get(i).isRole()) {
                            fg = true;
                        } else {
                            fg = false;
                        }
                        break;
                    } else {
                        continue;
                    }
                }

                if (flag == 1) {
                    FXMLLoader fdr = new FXMLLoader(getClass().getResource("UserW.fxml"));
                    Parent root1 = (Parent) fdr.load();
                    Stage sge = new Stage();
                    sge.initModality(Modality.APPLICATION_MODAL);
                    sge.setTitle("Panel");
                    sge.setScene(new Scene(root1));
                    Stage ee = (Stage) loginB.getScene().getWindow();
                    ee.hide();
                    sge.show();
                } else {
                    countTimes++;
                    Alert warn = new Alert(Alert.AlertType.WARNING, "Attempts are limited to 3!");
                    warn.show();
                }
                if (countTimes == 3) {
                    Platform.exit();
                }
            } catch (Exception p) {
                System.out.println(p.getMessage());

            }
        } catch (Exception exp) {
            Alert wr = new Alert(Alert.AlertType.NONE, "Error!");
            System.out.println(exp.getMessage());
        }
    }
}



